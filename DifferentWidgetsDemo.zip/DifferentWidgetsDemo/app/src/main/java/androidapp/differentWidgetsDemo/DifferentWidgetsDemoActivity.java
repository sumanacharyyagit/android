package androidapp.differentWidgetsDemo;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import android.widget.ToggleButton;
import android.widget.Switch;
import android.widget.RadioGroup.OnCheckedChangeListener;


public class DifferentWidgetsDemoActivity extends Activity {
	DatePicker dtp;
	EditText edt;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        //---Button view---
        ImageButton button2 = (ImageButton) findViewById(R.id.imageButton1);
        button2.setOnClickListener(new View.OnClickListener() {
        	public void onClick(View v) {
        		DisplayToast("You have clicked the Save button");
        	}
        });
        
        //---CheckBox---
        CheckBox checkBox1 = (CheckBox) findViewById(R.id.checkBox1);
        checkBox1.setOnClickListener(new View.OnClickListener() {
        	public void onClick(View v) {
        		if (((CheckBox)v).isChecked())
        			DisplayToast("CheckBox is checked");
        		else
        			DisplayToast("CheckBox is unchecked");
        	}
        });
        
        //---RadioButton---
        RadioGroup radioGroup = (RadioGroup) findViewById(R.id.rdbGp1);
        radioGroup.setOnCheckedChangeListener(new OnCheckedChangeListener() {
        	public void onCheckedChanged(RadioGroup group, int checkedId) {
        		RadioButton rb1 = (RadioButton) findViewById(R.id.rdb1);
        		if (rb1.isChecked())
        			DisplayToast("Option 1 checked!");
        		else
        			DisplayToast("Option 2 checked!");
        	}
        });
        
        //---ToggleButton---
        ToggleButton toggleButton = (ToggleButton) findViewById(R.id.toggle1);
        toggleButton.setOnClickListener(new View.OnClickListener() {
        	public void onClick(View v) {
        		if (((ToggleButton)v).isChecked())
        			DisplayToast("Toggle button is On");
        		else
        			DisplayToast("Toggle button is Off");
        	}
        });

        //---Switch----//
		final Switch myswitch = (Switch) findViewById(R.id.simpleSwitch);
		myswitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
				//Toast.makeText(getApplicationContext(),String.valueOf(b),Toast.LENGTH_LONG).show();
				if(b)
					Toast.makeText(getApplicationContext(),myswitch.getTextOn(),Toast.LENGTH_LONG).show();
				else
					Toast.makeText(getApplicationContext(),myswitch.getTextOff(),Toast.LENGTH_LONG).show();
			}
		});

        //---EditText---
        edt = (EditText) findViewById(R.id.editText1);
        
        //---DatePicker---
        dtp = (DatePicker) findViewById(R.id.datePicker1);
        
        //---Button view---
        
        Button button1 = (Button) findViewById(R.id.button1);
        button1.setOnClickListener(new View.OnClickListener() {
        	public void onClick(View v) {
        		int y = dtp.getYear();
        		int m = dtp.getMonth();
        		int d = dtp.getDayOfMonth();
        		
        		edt.setText(new StringBuilder()
        		.append(y).append("-")
        		.append(m + 1).append("-") //Month is 0 based so add 1
        		.append(d).append(""));
        		
        		//DisplayToast("You have clicked the Open button");
        	}
        });
        
    }
    
    private void DisplayToast(String msg) {
        Toast.makeText(getBaseContext(), msg, Toast.LENGTH_SHORT).show();
    }
}