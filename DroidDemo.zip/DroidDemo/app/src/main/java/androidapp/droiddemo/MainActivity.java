package androidapp.droiddemo;

import android.os.Bundle;
import android.app.Activity;
import android.graphics.Typeface;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
	TextView hb_tv1, hb_tv2, b_tv1, b_tv2;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //---Set Orientation to Landscape---
        //setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        //---Remove title bar---
        //requestWindowFeature(Window.FEATURE_NO_TITLE);
		/*
        if(getResources().getConfiguration().orientation == 2)
        	setContentView(R.layout.activity_main_landscape); //---Landscape
        else
        	setContentView(R.layout.activity_main); //---portrait
		*/
        setContentView(R.layout.activity_main);
        bindViews();
    }
    
    public void bindViews() {
    	Typeface tf = Typeface.createFromAsset(getAssets(), "fonts/Roboto-Light.ttf");
    	hb_tv1 = (TextView) findViewById(R.id.hb_tv1);
    	hb_tv1.setTypeface(tf);
    	hb_tv2 = (TextView) findViewById(R.id.hb_tv2);
    	hb_tv2.setTypeface(tf);
    	//b_tv1 = (TextView) findViewById(R.id.b_tv1);
    	//b_tv1.setTypeface(tf);
    	b_tv2 = (TextView) findViewById(R.id.b_tv2);
    	b_tv2.setTypeface(tf);
    }
}
