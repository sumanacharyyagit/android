package testapp.wbg.com.msgfromact1toact2;

import android.app.Activity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class Activity2 extends Activity {
    TextView edt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);
        edt = (TextView) findViewById(R.id.tv3);
        String s = getIntent().getStringExtra("key1");
        edt.setText(s);
    }
}
