package testapp.wbg.com.msgfromact1toact2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends Activity {
    EditText edt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edt = (EditText) findViewById(R.id.edt1);
    }

    public void btnClick(View v) {
        String s = edt.getText().toString();
        Intent i = new Intent(this,Activity2.class);
        i.putExtra("key1",s);
        startActivity(i);
    }
}
