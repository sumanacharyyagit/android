package testapp.wbg.com.relativelayoutrecap;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    EditText edt_name,edt_email,edt_phone;
    Button btn_save; //, btn_cancel;
    TextView tv_result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bindViews();
    }

    private void bindViews() {
        edt_name = (EditText) findViewById(R.id.edt_name);
        edt_email = (EditText) findViewById(R.id.edt_email);
        edt_phone = (EditText) findViewById(R.id.edt_phone);

        btn_save = (Button) findViewById(R.id.btn_save);
        //btn_cancel = (Button) findViewById(R.id.btn_cancel);

        tv_result = (TextView) findViewById(R.id.tv_show);

        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nm = edt_name.getText().toString();
                String em = edt_email.getText().toString();
                String ph = edt_phone.getText().toString();

                tv_result.setText("Name : " + nm + "\n" + "Email : " + em + "\n" + "Phone : " + ph);
            }
        });
    }

    public void close(View v) {
        Toast.makeText(this, "Goodbye", Toast.LENGTH_LONG).show();
        finish();
    }
}
