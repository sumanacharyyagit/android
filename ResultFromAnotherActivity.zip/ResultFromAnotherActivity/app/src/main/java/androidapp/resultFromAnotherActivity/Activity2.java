package androidapp.resultFromAnotherActivity;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.widget.*;

public class Activity2 extends Activity {
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);


		LinearLayout ll = new LinearLayout(this);
        ll.setOrientation(LinearLayout.VERTICAL);

		TextView myTextView = new TextView(this);
		final EditText txt_username = new EditText(this);
		Bundle extras = getIntent().getExtras();
		if (extras!=null) {
			myTextView.setText(extras.getString("lname"));
			txt_username.setHint(extras.getString("fname"));
		}

        Button myButton = new Button(this);
        



        myButton.setText("Click Here!");
        
        ll.addView(myTextView);
        ll.addView(txt_username);
        ll.addView(myButton);
        
		//---event handler for the OK button---
		myButton.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View view) {
				Intent i = new Intent();
				//---get the EditText view---
				String s = txt_username.getText().toString();
				//---set the data to pass back---
				i.setData(Uri.parse(s));
				setResult(RESULT_OK, i);
				//---closes the activity---
				finish();
			}
		});
		setContentView(ll);
	}
}