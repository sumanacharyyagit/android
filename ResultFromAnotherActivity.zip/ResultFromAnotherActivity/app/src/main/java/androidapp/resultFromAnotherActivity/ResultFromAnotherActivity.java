package androidapp.resultFromAnotherActivity;

import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;

import org.w3c.dom.Text;

public class ResultFromAnotherActivity extends Activity {
	final int request_Code = 1;
	EditText edt;
	TextView tv2;
	String fname;

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        edt = (EditText) findViewById(R.id.edt);
        tv2 = (TextView) findViewById(R.id.tv2);
    }
    
    public void openActivity2(View view) {
		 	fname = edt.getText().toString();
    		Intent i = new Intent(this, Activity2.class);
    		Bundle extras = new Bundle();
    		extras.putString("lname", "Please Enter Your Last Name:");
			extras.putString("fname", fname);
    		i.putExtras(extras);
    		startActivityForResult(i, request_Code);
    }
    
    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
    	if (requestCode == request_Code) {
    		if (resultCode == RESULT_OK) {
    			//Toast.makeText(this, "Hello " + data.getData().toString() + "!", Toast.LENGTH_SHORT).show();

				tv2.setText(fname  + " " + intent.getData().toString());
    		}
    	}
    }
}