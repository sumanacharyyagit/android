package com.example.rajdipdatta.notifcompatdemo;

import android.app.Activity;
import android.app.NotificationManager;
import android.os.Bundle;
import android.support.v4.app.NotificationManagerCompat;

public class AlertDetails extends Activity {

    final int notificationId = 101;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alert_details);

        //---look up the notification manager service---
        //NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        //NotificationManagerCompat nm = NotificationManagerCompat.from(this);
        //---cancel the notification that we started
        //nm.cancel(getIntent().getExtras().getInt("notificationID"));
        //nm.cancel(notificationId);
    }
}
