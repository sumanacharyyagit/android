package androidapp.showdialog;

import android.app.Activity;
import android.os.Bundle;
import android.app.Dialog;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.*;
import android.widget.LinearLayout.LayoutParams;

public class ShowDialogDemoActivity extends Activity {
	CharSequence[] items = { "RED", "GREEN", "BLUE" };
	boolean[] itemsChecked = new boolean [items.length];
	//ProgressThread progressThread;
	Dialog fav_dialog = null;
	PopupWindow popup_dialog = null;
    ProgressDialog progressDialog;
    private static int progress;
    private int progressStatus = 0;
    LinearLayout mylayout;
    int r=0,g=0,b=0;
		
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        mylayout = (LinearLayout) findViewById(R.id.mylayout);
        
        Button btn1 = (Button) findViewById(R.id.button1);
        btn1.setOnClickListener(new View.OnClickListener() {
        	public void onClick(View v) {
        		showDialog(0);
        	}
        });
        
        Button btn2 = (Button) findViewById(R.id.button2);
        btn2.setOnClickListener(new View.OnClickListener() {
        	public void onClick(View v) {
        		showDialog(1);
        	}
        });
        
        Button btn4 = (Button) findViewById(R.id.button4);
        btn4.setOnClickListener(new View.OnClickListener() {
        	public void onClick(View v) {
        		showCustomDialog();
        	}
        });
        
        Button btn5 = (Button) findViewById(R.id.button5);
        btn5.setOnClickListener(new View.OnClickListener() {
        	public void onClick(View v) {
        		showPopupDialog();
        	}
        });
        
        Button btn3 = (Button) findViewById(R.id.button3);
        btn3.setOnClickListener(new View.OnClickListener() {
        	public void onClick(View v) {
        		showDialog(2);
        		
        		//---do some work in background thread---
                new Thread(new Runnable() {
                	public void run() {
                		//---do some work here---
                		while (progressStatus < 100) {
                			progressStatus = doSomeWork();
                			progressDialog.setProgress(progressStatus);
                		}
						progressStatus = 0;
                		progressDialog.dismiss();
                	}
                	
                	//---do some long lasting work here---
                	private int doSomeWork() {
                		try {
                			//---simulate doing some work---
                			progress+=10;
                			Thread.sleep(500);
                		} catch (InterruptedException e) {
                			e.printStackTrace();
                		}
                		return progress;
                	}
                }).start();
        		
        	} //End of btn3.onClick()
        });
    }
    
    protected Dialog onCreateDialog(int id) {
    	AlertDialog.Builder builder = new AlertDialog.Builder(this);
        switch(id) {
        case 0:
        	// do the work to define a simple Dialog
        	builder.setMessage("Are you sure you want to Exit?")
        			.setIcon(R.drawable.ic_launcher)
        			.setTitle("Exit App?")
        			.setCancelable(true)
        			.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
        	           public void onClick(DialogInterface dialog, int id) {
        	                finish();
        	           }
        	       })
        	       .setNegativeButton("No", new DialogInterface.OnClickListener() {
        	           public void onClick(DialogInterface dialog, int id) {
        	                dialog.cancel();
        	           }
        	       });
        	return (AlertDialog) builder.create();

        case 1:
            // do the work to define a Multi-Select Dialog
        	r=g=b=0;
        	builder.setTitle("Pick a color");
        	builder.setMultiChoiceItems(items, itemsChecked, new DialogInterface.OnMultiChoiceClickListener() {
        		public void onClick(DialogInterface dialog, int which, boolean isChecked) {
        			itemsChecked[which] = isChecked;
        			//Toast.makeText(getBaseContext(), items[which] + (itemsChecked[which] ? " checked!" : " unchecked!"), Toast.LENGTH_SHORT).show();
        		}
        	});
        	builder.setNeutralButton("Ok", new DialogInterface.OnClickListener() {
 	           public void onClick(DialogInterface dialog, int id) {
 	        	  if(itemsChecked[0]) r=255; else r=0;
 	        	  if(itemsChecked[1]) g=255; else g=0;
 	        	  if(itemsChecked[2]) b=255; else b=0;
 	        	  
 	        	  mylayout.setBackgroundColor(Color.argb(255, r, g, b));
	           }
        	});
        	return (AlertDialog) builder.create();
        	
        case 2:
            // do the work to define a Progress Dialog
        	progressDialog = new ProgressDialog(this);
            progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            progressDialog.setMessage("Loading...");
            return progressDialog;

        default:
            return null;
        }
    }
    
    private void showPopupDialog() {
		LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
    	View view = inflater.inflate(R.layout.fav_dialog, (ViewGroup) findViewById(R.id.dialog_root));

    	view.findViewById(R.id.no_btn).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                popup_dialog.dismiss();
            }
        });

    	view.findViewById(R.id.yes_btn).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
            	finish();
            	popup_dialog.dismiss();
            }
        });
    	
    	popup_dialog = new PopupWindow(view,LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT, true);
    	int screenWidth = getWindowManager().getDefaultDisplay().getWidth();
        int screenHeight = getWindowManager().getDefaultDisplay().getHeight();
        int x = screenWidth / 2;
        int y = screenHeight / 2;
        //int y = screenHeight / 2 - view.getMeasuredHeight() / 2;
    	popup_dialog.showAtLocation(getWindow().getDecorView().findViewById(android.R.id.content), Gravity.NO_GRAVITY, x, y);
	}
    
    private void showCustomDialog() {
		fav_dialog = new Dialog(this);
		fav_dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
    	View view = inflater.inflate(R.layout.fav_dialog, (ViewGroup) findViewById(R.id.dialog_root));

    	view.findViewById(R.id.no_btn).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                fav_dialog.dismiss();
            }
        });

    	view.findViewById(R.id.yes_btn).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
            	finish();
            	fav_dialog.dismiss();
            }
        });
    	
		fav_dialog.setContentView(view);
		fav_dialog.setCancelable(false);
		fav_dialog.show();
	}
}