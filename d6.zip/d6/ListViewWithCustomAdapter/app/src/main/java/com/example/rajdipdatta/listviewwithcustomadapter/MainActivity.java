package com.example.rajdipdatta.listviewwithcustomadapter;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ListView;

public class MainActivity extends Activity {
    ListView simpleList;
    String countryList[] = {"India", "China", "australia", "Portugle", "America", "NewZealand", "Croatia", "Bangladesh"};
    int flags[] = {R.drawable.india, R.drawable.china, R.drawable.australia, R.drawable.portugle, R.drawable.america, R.drawable.new_zealand, R.drawable.croatia, R.drawable.bangladesh};
    String capitals[] = {"Delhi", "Beijing", "Canberra", "Lisbon", "Washington", "Wellington", "Zagreb", "Dhaka"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        simpleList = (ListView) findViewById(R.id.simpleListView);
        CustomAdapter customAdapter = new CustomAdapter(
                getApplicationContext(),
                countryList, flags, capitals);
        simpleList.setAdapter(customAdapter);
    }
}
