package myappapp2.wbg.com.mysimplecalculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView tv;
    int op1, op2, r;
    boolean flg = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv = (TextView) findViewById(R.id.tv);
    }

    public void btnClick(View v) {
        //if(flg) {tv.setText(""); flg=false;}
        String tvs = tv.getText().toString();
        String s = ((Button)v).getText().toString();
        tvs = tvs + s;
        tv.setText(tvs);
    }

    public void plusClick(View v) {
        String s = tv.getText().toString();
        op1 = Integer.parseInt(s);
        String symbol = ((Button)v).getText().toString();
        s = s + symbol;
        tv.setText(s);
        flg = true;
    }

    public void equalsClick(View v) {
        String s = tv.getText().toString();
        s = s.substring(s.indexOf('+')+1);
        op2 = Integer.parseInt(s);
        r = op1 + op2;
        tv.setText(String.valueOf(r));
        flg = true;
    }
}
